package com.tugasakhir.kalkulator_bmi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.tugasakhir.kalkulator_bmi.Boy.MainActivity2
import com.tugasakhir.kalkulator_bmi.Girl.MainActivity
import kotlinx.android.synthetic.main.activity_gender.*

class Gender : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gender)

        boy.setOnClickListener{
          val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }

        girl.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}