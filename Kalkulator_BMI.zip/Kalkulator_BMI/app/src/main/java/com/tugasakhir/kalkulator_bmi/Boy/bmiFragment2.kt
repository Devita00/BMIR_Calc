package com.tugasakhir.kalkulator_bmi.Boy

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.tugasakhir.kalkulator_bmi.R
import kotlinx.android.synthetic.main.fragment_bmi.*

class bmiFragment2 : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bmi2, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupLinstener()
    }
    private fun massa(W: Float, H: Float): String {
        val TBm: Float = H / 100
        val BMI = (W) / (TBm * TBm)
        if (BMI < 18.5) {
            hasilbmi.setText("UNDERWEIGHT")
            gambar.setImageResource(R.drawable.man1)
        } else {
            if (BMI > 18.5 && BMI < 25) {
                hasilbmi.setText("NORMAL")
                gambar.setImageResource(R.drawable.man1)
            } else {
                if (BMI > 24.9 && BMI < 30) {
                    hasilbmi.setText("OVERWEIGHT")
                    gambar.setImageResource(R.drawable.man2)
                } else {
                    if (BMI > 29.9) {
                        hasilbmi.setText("OBESE")
                        gambar.setImageResource(R.drawable.man3)
                    }
                }
            }
        }
        return BMI.toString()
    }

    private fun berat(H: Float): String {
        val bbideal = (H - 100) - (0.1 * (H - 100))
        return bbideal.toString()
    }

    private fun setupLinstener() {
        tombol.setOnClickListener {
            val H: Float = inputTB.text.toString().toFloat()
            val W: Float = inputBB.text.toString().toFloat()
            nilaibmi.text = massa (W, H)
            nilaibbideal.text = berat(H)
        }
    }
}