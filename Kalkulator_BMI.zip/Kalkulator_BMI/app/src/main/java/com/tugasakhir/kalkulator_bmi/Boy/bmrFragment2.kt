package com.tugasakhir.kalkulator_bmi.Boy

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.tugasakhir.kalkulator_bmi.R
import kotlinx.android.synthetic.main.fragment_bmr.*
import kotlinx.android.synthetic.main.fragment_bmr.inputBB
import kotlinx.android.synthetic.main.fragment_bmr.inputTB
import kotlinx.android.synthetic.main.fragment_bmr.nilaibmr
import kotlinx.android.synthetic.main.fragment_bmr.nilaibmr2
import kotlinx.android.synthetic.main.fragment_bmr.radio
import kotlinx.android.synthetic.main.fragment_bmr.tombol
import kotlinx.android.synthetic.main.fragment_bmr2.*

class bmrFragment2 : Fragment() {

    private var ACTIVITY: String? = null


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bmr2, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupLinstener()
    }

    private fun BMR(W: Double, H: Double, A: Double): String {
        val bmr = (13.397*W)+(4.799*H)-(5.677*A)+88.362
        return bmr.toString()
    }

    private fun BMR2(W: Double, H: Double, A: Double): String {
        val bmr = (13.397*W)+(4.799*H)-(5.677*A)+88.362
        var bmr2: Double = 0.0
        when(ACTIVITY){
            level1 -> bmr2 = bmr*1.2
            level2 -> bmr2 = bmr*1.4
            level3 -> bmr2 = bmr*1.5
            level4 -> bmr2 = bmr*1.7
            level5 -> bmr2 = bmr*1.8
            level6 -> bmr2 = bmr*1.9
        }
        return bmr2.toString()
    }

    private fun setupLinstener() {
        tombol.setOnClickListener {
            val W: Double = inputTB.text.toString().toDouble()
            val H: Double = inputBB.text.toString().toDouble()
            val A: Double = inputBB.text.toString().toDouble()
            nilaibmr.text = BMR(W, H, A)
            nilaibmr2.text = BMR2(W, H, A)
        }
        radio.setOnCheckedChangeListener { group, checkedId ->
            val radioButton = fin
        }
    }
}