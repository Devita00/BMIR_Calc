package com.tugasakhir.kalkulator_bmi

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import kotlinx.android.synthetic.main.fragment_bmr.*

class bmrFragment : Fragment() {

    private var ACTIVITY: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_bmr, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupLinstener()
    }

    private fun BMR(W: Double, H: Double, A: Double): String {
        val bmr = (9.247*W)+(3.098*H)-(4.33*A)+447.593
        return bmr.toString()
    }

    private fun BMR2(W: Double, H: Double, A: Double): String {
        val bmr = (9.247*W)+(3.098*H)-(4.33*A)+447.593
        var bmr2: Double = 0.0
        when(ACTIVITY){
            "Sedentary: little or no exercise" -> bmr2 = bmr*1.2
            "Exercise 1-3 times/week" -> bmr2 = bmr*1.4
            "Exercise 4-5 times/week" -> bmr2 = bmr*1.5
            "Intense exercise 3-4 times/week" -> bmr2 = bmr*1.7
            "Intense exercise 6-7 times/week" -> bmr2 = bmr*1.8
            "Very intense exercise daily, or physical job" -> bmr2 = bmr*1.9
        }
        return bmr2.toString()
    }

    private fun setupLinstener() {
        tombol.setOnClickListener {
            val W: Double = inputTB.text.toString().toDouble()
            val H: Double = inputBB.text.toString().toDouble()
            val A: Double = inputBB.text.toString().toDouble()
            nilaibmr.text = BMR(W, H, A)
            nilaibmr2.text = BMR2(W, H, A)
        }
    }
}