package com.tugasakhir.kalkulator_bmi.Girl

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.tugasakhir.kalkulator_bmi.R
import com.tugasakhir.kalkulator_bmi.aboutFragment
import com.tugasakhir.kalkulator_bmi.bmiFragment
import com.tugasakhir.kalkulator_bmi.bmrFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val bmiFragment = bmiFragment()
    private val bmrFragment = bmrFragment()
    private val aboutFragment = aboutFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        replaceFragment(bmiFragment)

        navbar.setOnNavigationItemSelectedListener {
            when(it.itemId){
            R.id.bmi -> replaceFragment(bmiFragment)
            R.id.bmr -> replaceFragment(bmrFragment)
            R.id.about -> replaceFragment(aboutFragment)
        }
            true
        }
    }

    private fun replaceFragment(fragment: Fragment){
        if(fragment !=null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment, fragment)
            transaction.commit()

        }
    }

}