package com.tugasakhir.kalkulator_bmi.Boy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.tugasakhir.kalkulator_bmi.Gender
import com.tugasakhir.kalkulator_bmi.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity2 : AppCompatActivity() {

    private val bmiFragment2 = bmiFragment2()
    private val bmrFragment2 = bmrFragment2()
    private val aboutFragment2 = AboutFragment2()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        replaceFragment(bmiFragment2)

        navbar.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.bmi -> replaceFragment(bmiFragment2)
                R.id.bmr -> replaceFragment(bmrFragment2)
                R.id.about -> replaceFragment(aboutFragment2)
            }
            true
        }
    }

    private fun replaceFragment(fragment: Fragment){
        if(fragment !=null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment, fragment)
            transaction.commit()

        }
    }
}