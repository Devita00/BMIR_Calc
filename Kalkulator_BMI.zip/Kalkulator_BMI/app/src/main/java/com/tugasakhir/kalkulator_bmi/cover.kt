package com.tugasakhir.kalkulator_bmi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.tugasakhir.kalkulator_bmi.Girl.MainActivity
import kotlinx.android.synthetic.main.activity_cover.*

class cover : AppCompatActivity() {

    private val SPLASH_TIME: Long = 4000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cover)

        logo.animate().apply {
            duration = 1000
            rotationYBy(360f)
        }.withEndAction {
            logo.animate().apply {
                duration = 500
                rotationYBy(360f)
            }
        }

        Handler().postDelayed({
            startActivity(Intent(this, Gender::class.java))
            finish()
        },SPLASH_TIME)
    }
}